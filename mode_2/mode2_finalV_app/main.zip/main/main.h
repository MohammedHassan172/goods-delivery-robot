#ifndef MAIN_H
#define MAIN_H

#define MAX_X 3
#define MAX_Y 3

/*************************includes*************************************/

#include "Motor_moving.h"
#include "linefollower.h"
#include "Ultrasonic.h"

/*************************data declearation*************************************/
/*************************Functions*************************************/
#endif
